FileSystem Configuration Example
--------------------------------

This folder contains configuration files for IgniteFs examples located in
org.apache.ignite.examples.igfs package.

- example-igfs.xml file is used to start Apache Ignite nodes with IgniteFS configured
- core-site.xml file is used to run Hadoop FS driver over IgniteFs
